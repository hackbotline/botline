goohacker

This is tutorial on English :

pkg install python2 -y
Pkg install git -y
git clone http://github.com/merkremont/LineVodka
pip2 install thrift==0.9.3
pkg install rsa
pip2 install requests
pip2 install rsa
cd LineVodka
python2 vodkabot.py
https://youtu.be/_Iqxe1hfb0Q