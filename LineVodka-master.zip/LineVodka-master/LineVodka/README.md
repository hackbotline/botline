# LineVodka
_May the Vodka be with you..._

Tutorial
------
Recomended for python 2.7

Using git :

    $ git clone http://github.com/merkremont/LineVodka

Python packages :

    $ pip install thrift==0.9.3
    $ pip install rsa
    $ pip install requests

Run Vodka :

    $ python vodkabot.py

Video Tutorial
------

[![Tutorial Build BOT LINE Unofficial Protector and Kicker Group](http://i.imgur.com/C8xYq7v.png "Tutorial Build BOT LINE Unofficial Protector and Kicker Group")](https://youtu.be/anoF3jnWl2A)

Author
------

Merk Kremont / [@merkremont](https://twitter.com/merkremont)
